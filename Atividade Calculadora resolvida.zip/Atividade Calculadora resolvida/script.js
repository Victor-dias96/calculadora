
const display = document.getElementById('display');


let currentInput = '';


function updateDisplay() {
    display.textContent = currentInput || '0';
}


function handleNumber(number) {
    currentInput += number;
    updateDisplay();
}


function handleOperator(op) {
    if (currentInput === '') return;
    currentInput += op;  
    updateDisplay();
}


function calculate() {
    if (currentInput === '') return;

    try {
        currentInput = eval(currentInput).toString(); 
    } catch (error) {
        currentInput = 'Error'; 
    }
    
    updateDisplay();
}


function clearDisplay() {
    currentInput = '';
    updateDisplay();
}


function backspace() {
    currentInput = currentInput.slice(0, -1);
    updateDisplay();
}


document.querySelectorAll('.btn').forEach(button => {
    button.addEventListener('click', () => {
        const buttonText = button.textContent;

        if (!isNaN(buttonText) || buttonText === '.') {
            handleNumber(buttonText);
        } else if (buttonText === 'C') {
            clearDisplay();
        } else if (buttonText === '<') {
            backspace();
        } else if (buttonText === '=') {
            calculate();
        } else {
            handleOperator(buttonText);
        }
    });
});


updateDisplay();

function operate(op, a, b) {
    switch (op) {
        case '+':
            return a + b;
        case '-':
            return a - b;
        case '*': 
            return a * b;
        case '/':
            return a / b;
        default:
            return b;
    }
}
